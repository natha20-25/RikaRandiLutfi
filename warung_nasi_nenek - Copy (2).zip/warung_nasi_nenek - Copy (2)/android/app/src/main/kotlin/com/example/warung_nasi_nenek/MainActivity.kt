package com.example.warung_nasi_nenek

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
