import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/main_screen.dart';
import 'services/order_service.dart';
import 'services/profile_service.dart';
import 'services/settings_service.dart';
import 'services/payment_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final orderService = OrderService(prefs);
  final profileService = ProfileService(prefs);
  final settingsService = SettingsService(prefs);
  final paymentService = PaymentService(prefs);

  runApp(MyApp(
    orderService: orderService,
    profileService: profileService,
    settingsService: settingsService,
    paymentService: paymentService,
  ));
}

class MyApp extends StatelessWidget {
  final OrderService orderService;
  final ProfileService profileService;
  final SettingsService settingsService;
  final PaymentService paymentService;

  const MyApp({
    Key? key,
    required this.orderService,
    required this.profileService,
    required this.settingsService,
    required this.paymentService,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Warung Nasi Nenek',
      theme: ThemeData(
        primarySwatch: Colors.orange,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MainScreen(
        orderService: orderService,
        profileService: profileService,
        settingsService: settingsService,
        paymentService: paymentService,
      ),
    );
  }
}
