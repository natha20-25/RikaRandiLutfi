class Order {
  final String id;
  final String menuName;
  final int price;
  final int quantity;
  final DateTime orderTime;
  final String status;

  Order({
    required this.id,
    required this.menuName,
    required this.price,
    required this.quantity,
    required this.orderTime,
    required this.status,
  });

  int get totalPrice => price * quantity;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'menuName': menuName,
      'price': price,
      'quantity': quantity,
      'orderTime': orderTime.toIso8601String(),
      'status': status,
    };
  }

  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      id: json['id'],
      menuName: json['menuName'],
      price: json['price'],
      quantity: json['quantity'],
      orderTime: DateTime.parse(json['orderTime']),
      status: json['status'],
    );
  }
} 