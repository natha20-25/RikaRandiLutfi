class Profile {
  final String name;
  final String email;
  final String? address;
  final String? phoneNumber;
  final String? profileImage;

  Profile({
    required this.name,
    required this.email,
    this.address,
    this.phoneNumber,
    this.profileImage,
  });

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'email': email,
      'address': address,
      'phoneNumber': phoneNumber,
      'profileImage': profileImage,
    };
  }

  factory Profile.fromJson(Map<String, dynamic> json) {
    return Profile(
      name: json['name'] ?? 'Nenek Warung',
      email: json['email'] ?? 'nenek@warung.com',
      address: json['address'],
      phoneNumber: json['phoneNumber'],
      profileImage: json['profileImage'],
    );
  }

  Profile copyWith({
    String? name,
    String? email,
    String? address,
    String? phoneNumber,
    String? profileImage,
  }) {
    return Profile(
      name: name ?? this.name,
      email: email ?? this.email,
      address: address ?? this.address,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      profileImage: profileImage ?? this.profileImage,
    );
  }
} 