class PaymentMethod {
  final String id;
  final String name;
  final String type;
  final bool isActive;

  PaymentMethod({
    required this.id,
    required this.name,
    required this.type,
    required this.isActive,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'type': type,
      'isActive': isActive,
    };
  }

  factory PaymentMethod.fromJson(Map<String, dynamic> json) {
    return PaymentMethod(
      id: json['id'],
      name: json['name'],
      type: json['type'],
      isActive: json['isActive'] ?? false,
    );
  }

  PaymentMethod copyWith({
    String? id,
    String? name,
    String? type,
    bool? isActive,
  }) {
    return PaymentMethod(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      isActive: isActive ?? this.isActive,
    );
  }
} 