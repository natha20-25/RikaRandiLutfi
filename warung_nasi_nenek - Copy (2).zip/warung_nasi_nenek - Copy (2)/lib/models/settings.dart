class Settings {
  final bool notifications;
  final bool darkMode;
  final bool location;

  Settings({
    required this.notifications,
    required this.darkMode,
    required this.location,
  });

  Map<String, dynamic> toJson() {
    return {
      'notifications': notifications,
      'darkMode': darkMode,
      'location': location,
    };
  }

  factory Settings.fromJson(Map<String, dynamic> json) {
    return Settings(
      notifications: json['notifications'] ?? true,
      darkMode: json['darkMode'] ?? false,
      location: json['location'] ?? true,
    );
  }

  Settings copyWith({
    bool? notifications,
    bool? darkMode,
    bool? location,
  }) {
    return Settings(
      notifications: notifications ?? this.notifications,
      darkMode: darkMode ?? this.darkMode,
      location: location ?? this.location,
    );
  }
} 