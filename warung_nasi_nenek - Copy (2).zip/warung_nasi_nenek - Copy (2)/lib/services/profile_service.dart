import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/profile.dart';

class ProfileService {
  static const String _profileKey = 'user_profile';
  final SharedPreferences _prefs;

  ProfileService(this._prefs);

  Future<Profile> getProfile() async {
    final String? profileJson = _prefs.getString(_profileKey);
    if (profileJson == null) {
      return Profile(name: 'Nenek Warung', email: 'nenek@warung.com');
    }
    return Profile.fromJson(json.decode(profileJson));
  }

  Future<void> updateProfile(Profile profile) async {
    final String profileJson = json.encode(profile.toJson());
    await _prefs.setString(_profileKey, profileJson);
  }

  Future<void> updateAddress(String address) async {
    final profile = await getProfile();
    await updateProfile(profile.copyWith(address: address));
  }

  Future<void> updatePhoneNumber(String phoneNumber) async {
    final profile = await getProfile();
    await updateProfile(profile.copyWith(phoneNumber: phoneNumber));
  }

  Future<void> updateProfileImage(String imagePath) async {
    final profile = await getProfile();
    await updateProfile(profile.copyWith(profileImage: imagePath));
  }
} 