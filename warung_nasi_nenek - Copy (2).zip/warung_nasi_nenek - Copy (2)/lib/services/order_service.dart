import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/order.dart';

class OrderService {
  static const String _ordersKey = 'orders';
  final SharedPreferences _prefs;

  OrderService(this._prefs);

  Future<List<Order>> getOrders() async {
    final String? ordersJson = _prefs.getString(_ordersKey);
    if (ordersJson == null) return [];

    final List<dynamic> ordersList = json.decode(ordersJson);
    return ordersList.map((json) => Order.fromJson(json)).toList();
  }

  Future<void> addOrder(Order order) async {
    final List<Order> orders = await getOrders();
    orders.add(order);
    await _saveOrders(orders);
  }

  Future<void> updateOrderStatus(String orderId, String newStatus) async {
    final List<Order> orders = await getOrders();
    final index = orders.indexWhere((order) => order.id == orderId);
    if (index != -1) {
      final order = orders[index];
      orders[index] = Order(
        id: order.id,
        menuName: order.menuName,
        price: order.price,
        quantity: order.quantity,
        orderTime: order.orderTime,
        status: newStatus,
      );
      await _saveOrders(orders);
    }
  }

  Future<void> deleteOrder(String orderId) async {
    final List<Order> orders = await getOrders();
    orders.removeWhere((order) => order.id == orderId);
    await _saveOrders(orders);
  }

  Future<void> _saveOrders(List<Order> orders) async {
    final String ordersJson = json.encode(orders.map((order) => order.toJson()).toList());
    await _prefs.setString(_ordersKey, ordersJson);
  }
} 