import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/settings.dart';

class SettingsService {
  static const String _settingsKey = 'app_settings';
  final SharedPreferences _prefs;

  SettingsService(this._prefs);

  Future<Settings> getSettings() async {
    final String? settingsJson = _prefs.getString(_settingsKey);
    if (settingsJson == null) {
      return Settings(notifications: true, darkMode: false, location: true);
    }
    return Settings.fromJson(json.decode(settingsJson));
  }

  Future<void> updateSettings(Settings settings) async {
    final String settingsJson = json.encode(settings.toJson());
    await _prefs.setString(_settingsKey, settingsJson);
  }

  Future<void> toggleNotifications(bool value) async {
    final settings = await getSettings();
    await updateSettings(settings.copyWith(notifications: value));
  }

  Future<void> toggleDarkMode(bool value) async {
    final settings = await getSettings();
    await updateSettings(settings.copyWith(darkMode: value));
  }

  Future<void> toggleLocation(bool value) async {
    final settings = await getSettings();
    await updateSettings(settings.copyWith(location: value));
  }
} 