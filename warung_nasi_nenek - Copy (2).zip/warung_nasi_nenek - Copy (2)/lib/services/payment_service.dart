import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/payment_method.dart';

class PaymentService {
  static const String _paymentMethodsKey = 'payment_methods';
  final SharedPreferences _prefs;

  PaymentService(this._prefs);

  Future<List<PaymentMethod>> getPaymentMethods() async {
    final String? methodsJson = _prefs.getString(_paymentMethodsKey);
    if (methodsJson == null) {
      // Default payment methods
      final defaultMethods = [
        PaymentMethod(
          id: '1',
          name: 'Cash',
          type: 'cash',
          isActive: true,
        ),
        PaymentMethod(
          id: '2',
          name: 'Transfer Bank',
          type: 'bank',
          isActive: false,
        ),
        PaymentMethod(
          id: '3',
          name: 'E-Wallet',
          type: 'ewallet',
          isActive: false,
        ),
      ];
      await savePaymentMethods(defaultMethods);
      return defaultMethods;
    }
    final List<dynamic> methodsList = json.decode(methodsJson);
    return methodsList.map((json) => PaymentMethod.fromJson(json)).toList();
  }

  Future<void> savePaymentMethods(List<PaymentMethod> methods) async {
    final String methodsJson = json.encode(methods.map((m) => m.toJson()).toList());
    await _prefs.setString(_paymentMethodsKey, methodsJson);
  }

  Future<void> setActivePaymentMethod(String methodId) async {
    final methods = await getPaymentMethods();
    final updatedMethods = methods.map((method) {
      return method.copyWith(isActive: method.id == methodId);
    }).toList();
    await savePaymentMethods(updatedMethods);
  }

  Future<void> addPaymentMethod(PaymentMethod method) async {
    final methods = await getPaymentMethods();
    methods.add(method);
    await savePaymentMethods(methods);
  }

  Future<void> removePaymentMethod(String methodId) async {
    final methods = await getPaymentMethods();
    methods.removeWhere((method) => method.id == methodId);
    await savePaymentMethods(methods);
  }
} 