import 'package:flutter/material.dart';
import '../services/profile_service.dart';
import '../services/settings_service.dart';
import '../services/payment_service.dart';
import '../services/order_service.dart';
import '../models/profile.dart';
import '../models/settings.dart';
import '../models/payment_method.dart';
import '../models/order.dart';

class ProfilePage extends StatefulWidget {
  final ProfileService profileService;
  final SettingsService settingsService;
  final PaymentService paymentService;
  final OrderService orderService;

  const ProfilePage({
    Key? key,
    required this.profileService,
    required this.settingsService,
    required this.paymentService,
    required this.orderService,
  }) : super(key: key);

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late Future<Profile> _profileFuture;
  late Future<Settings> _settingsFuture;
  late Future<List<PaymentMethod>> _paymentMethodsFuture;
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _addressController = TextEditingController();
  final _phoneController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  void _loadData() {
    _profileFuture = widget.profileService.getProfile();
    _settingsFuture = widget.settingsService.getSettings();
    _paymentMethodsFuture = widget.paymentService.getPaymentMethods();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profil Saya'),
        backgroundColor: Colors.orange,
        elevation: 0,
      ),
      body: FutureBuilder<Profile>(
        future: _profileFuture,
        builder: (context, profileSnapshot) {
          if (profileSnapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          final profile = profileSnapshot.data!;
          _nameController.text = profile.name;
          _emailController.text = profile.email;
          _addressController.text = profile.address ?? '';
          _phoneController.text = profile.phoneNumber ?? '';

          return SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  color: Colors.orange,
                  padding: EdgeInsets.only(bottom: 20),
                  child: Column(
                    children: [
                      SizedBox(height: 20),
                      CircleAvatar(
                        radius: 50,
                        backgroundColor: Colors.white,
                        backgroundImage: AssetImage('lib/assets/images/profil.jpeg'),
                      ),
                      SizedBox(height: 10),
                      Text(
                        profile.name,
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        profile.email,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    children: [
                      _buildMenuItem(
                        icon: Icons.person_outline,
                        title: 'Edit Profil',
                        onTap: () => _showEditProfileDialog(context, profile),
                      ),
                      _buildMenuItem(
                        icon: Icons.shopping_bag_outlined,
                        title: 'Pesanan Saya',
                        onTap: () => _showOrdersDialog(context),
                      ),
                      _buildMenuItem(
                        icon: Icons.location_on_outlined,
                        title: 'Alamat',
                        onTap: () => _showAddressDialog(context, profile),
                      ),
                      _buildMenuItem(
                        icon: Icons.phone_outlined,
                        title: 'Nomor Telepon',
                        onTap: () => _showPhoneDialog(context, profile),
                      ),
                      _buildMenuItem(
                        icon: Icons.payment_outlined,
                        title: 'Metode Pembayaran',
                        onTap: () => _showPaymentMethodsDialog(context),
                      ),
                      _buildMenuItem(
                        icon: Icons.settings_outlined,
                        title: 'Pengaturan',
                        onTap: () => _showSettingsDialog(context),
                      ),
                      _buildMenuItem(
                        icon: Icons.help_outline,
                        title: 'Bantuan',
                        onTap: () => _showHelpDialog(context),
                      ),
                      SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: () => _showLogoutDialog(context),
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all(Colors.red),
                          padding: MaterialStateProperty.all(
                            EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                          ),
                          shape: MaterialStateProperty.all(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                        ),
                        child: Text(
                          'Keluar',
                          style: TextStyle(fontSize: 16),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 15),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: Colors.grey.shade200,
              width: 1,
            ),
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.orange),
            SizedBox(width: 15),
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black87,
              ),
            ),
            Spacer(),
            Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
          ],
        ),
      ),
    );
  }

  void _showEditProfileDialog(BuildContext context, Profile profile) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Profil'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Nama'),
            ),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              final updatedProfile = profile.copyWith(
                name: _nameController.text,
                email: _emailController.text,
              );
              await widget.profileService.updateProfile(updatedProfile);
              setState(() {
                _loadData();
              });
              Navigator.pop(context);
            },
            child: Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void _showOrdersDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => FutureBuilder<List<Order>>(
        future: widget.orderService.getOrders(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return AlertDialog(
              content: Center(child: CircularProgressIndicator()),
            );
          }

          final orders = snapshot.data!;
          if (orders.isEmpty) {
            return AlertDialog(
              title: Text('Pesanan Saya'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.history,
                    size: 60,
                    color: Colors.grey.shade400,
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Belum ada pesanan',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.grey.shade600,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.pushNamedAndRemoveUntil(
                      context,
                      '/',
                      (route) => false,
                    );
                  },
                  child: Text('Pesan Sekarang'),
                ),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('Tutup'),
                ),
              ],
            );
          }

          return AlertDialog(
            title: Text('Pesanan Saya'),
            content: Container(
              width: double.maxFinite,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Flexible(
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: orders.length,
                      itemBuilder: (context, index) {
                        final order = orders[index];
                        return Card(
                          margin: EdgeInsets.symmetric(vertical: 4),
                          child: ListTile(
                            title: Text(order.menuName),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Jumlah: ${order.quantity}'),
                                Text('Total: Rp ${order.totalPrice}'),
                                Text(
                                  'Waktu: ${_formatDateTime(order.orderTime)}',
                                  style: TextStyle(fontSize: 12),
                                ),
                              ],
                            ),
                            trailing: Container(
                              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: _getStatusColor(order.status),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                order.status,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pushNamedAndRemoveUntil(
                    context,
                    '/',
                    (route) => false,
                  );
                },
                child: Text('Pesan Baru'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Tutup'),
              ),
            ],
          );
        },
      ),
    );
  }

  String _formatDateTime(DateTime dateTime) {
    return '${dateTime.day}/${dateTime.month}/${dateTime.year} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Selesai':
        return Colors.green;
      case 'Diproses':
        return Colors.orange;
      case 'Menunggu Konfirmasi':
        return Colors.blue;
      default:
        return Colors.grey;
    }
  }

  void _showAddressDialog(BuildContext context, Profile profile) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Alamat'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _addressController,
              decoration: InputDecoration(
                labelText: 'Alamat',
                hintText: 'Masukkan alamat lengkap',
              ),
              maxLines: 3,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              await widget.profileService.updateAddress(_addressController.text);
              setState(() {
                _loadData();
              });
              Navigator.pop(context);
            },
            child: Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void _showPhoneDialog(BuildContext context, Profile profile) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Nomor Telepon'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _phoneController,
              decoration: InputDecoration(
                labelText: 'Nomor Telepon',
                hintText: 'Masukkan nomor telepon',
              ),
              keyboardType: TextInputType.phone,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              await widget.profileService.updatePhoneNumber(_phoneController.text);
              setState(() {
                _loadData();
              });
              Navigator.pop(context);
            },
            child: Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void _showPaymentMethodsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => FutureBuilder<List<PaymentMethod>>(
        future: _paymentMethodsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return AlertDialog(
              content: Center(child: CircularProgressIndicator()),
            );
          }

          final methods = snapshot.data!;
          return AlertDialog(
            title: Text('Metode Pembayaran'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: methods.map((method) => _buildPaymentMethodItem(method)).toList(),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Tutup'),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildPaymentMethodItem(PaymentMethod method) {
    return ListTile(
      leading: Icon(
        method.type == 'cash' ? Icons.money :
        method.type == 'bank' ? Icons.account_balance :
        Icons.account_balance_wallet,
        color: Colors.orange,
      ),
      title: Text(method.name),
      trailing: Icon(
        method.isActive ? Icons.check_circle : Icons.circle_outlined,
        color: method.isActive ? Colors.green : Colors.grey,
      ),
      onTap: () async {
        await widget.paymentService.setActivePaymentMethod(method.id);
        setState(() {
          _loadData();
        });
        Navigator.pop(context);
        _showPaymentMethodsDialog(context);
      },
    );
  }

  void _showSettingsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => FutureBuilder<Settings>(
        future: widget.settingsService.getSettings(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return AlertDialog(
              content: Center(child: CircularProgressIndicator()),
            );
          }

          final settings = snapshot.data!;
          return StatefulBuilder(
            builder: (context, setState) {
              return AlertDialog(
                title: Row(
                  children: [
                    Icon(Icons.settings, color: Colors.orange),
                    SizedBox(width: 8),
                    Text('Pengaturan'),
                  ],
                ),
                content: Container(
                  width: double.maxFinite,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Card(
                        elevation: 2,
                        child: SwitchListTile(
                          secondary: Icon(Icons.notifications, color: Colors.orange),
                          title: Text(
                            'Notifikasi',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text('Terima notifikasi pesanan'),
                          value: settings.notifications,
                          onChanged: (value) async {
                            try {
                              await widget.settingsService.toggleNotifications(value);
                              setState(() {
                                _loadData();
                              });
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Row(
                                    children: [
                                      Icon(Icons.check_circle, color: Colors.white),
                                      SizedBox(width: 8),
                                      Text('Pengaturan notifikasi diperbarui'),
                                    ],
                                  ),
                                  backgroundColor: Colors.green,
                                  duration: Duration(seconds: 2),
                                ),
                              );
                            } catch (e) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Gagal memperbarui pengaturan'),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          },
                        ),
                      ),
                      SizedBox(height: 8),
                      Card(
                        elevation: 2,
                        child: SwitchListTile(
                          secondary: Icon(Icons.dark_mode, color: Colors.orange),
                          title: Text(
                            'Mode Gelap',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text('Ubah tampilan aplikasi'),
                          value: settings.darkMode,
                          onChanged: (value) async {
                            try {
                              await widget.settingsService.toggleDarkMode(value);
                              setState(() {
                                _loadData();
                              });
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Row(
                                    children: [
                                      Icon(Icons.check_circle, color: Colors.white),
                                      SizedBox(width: 8),
                                      Text('Mode gelap diperbarui'),
                                    ],
                                  ),
                                  backgroundColor: Colors.green,
                                  duration: Duration(seconds: 2),
                                ),
                              );
                            } catch (e) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Gagal memperbarui pengaturan'),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          },
                        ),
                      ),
                      SizedBox(height: 8),
                      Card(
                        elevation: 2,
                        child: SwitchListTile(
                          secondary: Icon(Icons.location_on, color: Colors.orange),
                          title: Text(
                            'Lokasi',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text('Aktifkan deteksi lokasi'),
                          value: settings.location,
                          onChanged: (value) async {
                            try {
                              await widget.settingsService.toggleLocation(value);
                              setState(() {
                                _loadData();
                              });
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Row(
                                    children: [
                                      Icon(Icons.check_circle, color: Colors.white),
                                      SizedBox(width: 8),
                                      Text('Pengaturan lokasi diperbarui'),
                                    ],
                                  ),
                                  backgroundColor: Colors.green,
                                  duration: Duration(seconds: 2),
                                ),
                              );
                            } catch (e) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Gagal memperbarui pengaturan'),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                actions: [
                  TextButton.icon(
                    icon: Icon(Icons.close),
                    label: Text('Tutup'),
                    onPressed: () {
                      Navigator.pop(context);
                      setState(() {
                        _loadData();
                      });
                    },
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }

  void _showHelpDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Bantuan'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildHelpItem('Cara Memesan', Icons.shopping_cart),
            _buildHelpItem('Cara Pembayaran', Icons.payment),
            _buildHelpItem('Kontak Kami', Icons.phone),
            _buildHelpItem('FAQ', Icons.question_answer),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Widget _buildHelpItem(String title, IconData icon) {
    return ListTile(
      leading: Icon(icon, color: Colors.orange),
      title: Text(title),
      trailing: Icon(Icons.arrow_forward_ios, size: 16),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Keluar'),
        content: Text('Apakah Anda yakin ingin keluar dari aplikasi?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Batal'),
          ),
          TextButton(
            onPressed: () {
              // TODO: Implement logout logic
              Navigator.pop(context);
            },
            child: Text('Ya, Keluar'),
          ),
        ],
      ),
    );
  }
}
