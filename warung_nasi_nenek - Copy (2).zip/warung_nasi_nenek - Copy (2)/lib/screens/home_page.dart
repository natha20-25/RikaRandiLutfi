import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../services/order_service.dart';
import '../models/order.dart';

class HomePage extends StatelessWidget {
  final OrderService orderService;
  final List<Map<String, dynamic>> menuItems = [
    {'name': 'Ikan Nila goreng', 'price': 15000, 'image': 'ikan_goreng.jpeg'},
    {'name': 'Tahu goreng', 'price': 3000, 'image': 'tahu_goreng.jpeg'},
    {'name': 'Tempe goreng', 'price': 3000, 'image': 'tempe_goreng.jpeg'},
    {'name': 'Sayur toge tahu', 'price': 5000, 'image': 'sayur_toge.jpeg'},
    {'name': 'Capcay', 'price': 8000, 'image': 'capcay.jpeg'},
    {'name': 'Sayur terong', 'price': 5000, 'image': 'sayur_terong.jpeg'},
    {'name': 'Sayur lezet', 'price': 5000, 'image': 'sayur_lezet.jpeg'},
    {'name': 'Ayam kecap', 'price': 12000, 'image': 'ayam_kecap.jpeg'},
    {'name': 'Ayam opor + telor opor', 'price': 15000, 'image': 'ayam_opor.jpeg'},
    {'name': 'Nasi putih', 'price': 3000, 'image': 'nasi.jpeg'},
    {'name': 'Sambel', 'price': 1000, 'image': 'sambal.jpeg'},
    {'name': 'Lalapan', 'price': 2000, 'image': 'lalapan.jpeg'},
    {'name': 'Bacem tahu tempe', 'price': 5000, 'image': 'bacem_tempe.jpeg'},
    {'name': 'Perkedel', 'price': 2000, 'image': 'perkedel.jpeg'},
    {'name': 'Ayam goreng', 'price': 12000, 'image': 'ayam_goreng.jpeg'},
    {'name': 'Ikan tongkol', 'price': 10000, 'image': 'ikan_original.jpeg'},
    {'name': 'Ikan pindang goreng', 'price': 10000, 'image': 'ikan_goreng.jpeg'},
    {'name': 'Tempe tepung goreng', 'price': 4000, 'image': 'tempe_tepung.jpeg'},
    {'name': 'Ati ampela bumbu merah', 'price': 8000, 'image': 'ati_ampela.jpeg'},
    {'name': 'Kikil bumbu merah', 'price': 8000, 'image': 'kikil.jpeg'},
    {'name': 'Telur ceplok goreng', 'price': 3000, 'image': 'telur_goreng.jpeg'},
  ];

  HomePage({Key? key, required this.orderService}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Beranda'),
        backgroundColor: Colors.orange,
      ),
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.all(16),
            color: Colors.orange.shade50,
            child: Row(
              children: [
                Icon(Icons.info_outline, color: Colors.orange),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Pilih menu yang ingin Anda pesan',
                    style: TextStyle(color: Colors.orange.shade900),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: menuItems.length,
              itemBuilder: (context, index) {
                final item = menuItems[index];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: Image.asset(
                        'lib/assets/images/${item['image']}',
                        width: 60,
                        height: 60,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Icon(Icons.fastfood, size: 60, color: Colors.grey);
                        },
                      ),
                    ),
                    title: Text(item['name']),
                    subtitle: Text(
                      'Rp ${item['price'].toString()}',
                      style: TextStyle(
                        color: Colors.green,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    trailing: ElevatedButton(
                      onPressed: () {
                        _showOrderDialog(context, item);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      child: Text('Pesan'),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showOrderDialog(BuildContext context, Map<String, dynamic> item) {
    int quantity = 1;
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text('Pesan ${item['name']}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Harga: Rp ${item['price'].toString()}'),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: Icon(Icons.remove_circle_outline),
                    onPressed: quantity > 1
                        ? () {
                            setState(() {
                              quantity--;
                            });
                          }
                        : null,
                  ),
                  Text(
                    quantity.toString(),
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    icon: Icon(Icons.add_circle_outline),
                    onPressed: () {
                      setState(() {
                        quantity++;
                      });
                    },
                  ),
                ],
              ),
              SizedBox(height: 8),
              Text(
                'Total: Rp ${(item['price'] * quantity).toString()}',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () async {
                final order = Order(
                  id: Uuid().v4(),
                  menuName: item['name'],
                  price: item['price'],
                  quantity: quantity,
                  orderTime: DateTime.now(),
                  status: 'Menunggu Konfirmasi',
                );
                await orderService.addOrder(order);
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Pesanan berhasil dibuat!'),
                    backgroundColor: Colors.green,
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
              ),
              child: Text('Pesan'),
            ),
          ],
        ),
      ),
    );
  }
} 