import 'package:flutter/material.dart';
import '../services/order_service.dart';
import '../services/profile_service.dart';
import '../services/settings_service.dart';
import '../services/payment_service.dart';
import 'home_page.dart';
import 'riwayat_page.dart';
import 'profile_page.dart';

class MainScreen extends StatefulWidget {
  final OrderService orderService;
  final ProfileService profileService;
  final SettingsService settingsService;
  final PaymentService paymentService;

  const MainScreen({
    Key? key,
    required this.orderService,
    required this.profileService,
    required this.settingsService,
    required this.paymentService,
  }) : super(key: key);

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = <Widget>[
      HomePage(orderService: widget.orderService),
      RiwayatPage(orderService: widget.orderService),
      ProfilePage(
        profileService: widget.profileService,
        settingsService: widget.settingsService,
        paymentService: widget.paymentService,
        orderService: widget.orderService,
      ),
    ];
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.orange,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Beranda',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'Riwayat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
} 